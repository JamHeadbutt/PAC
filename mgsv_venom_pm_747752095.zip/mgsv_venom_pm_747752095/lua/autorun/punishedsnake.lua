player_manager.AddValidModel( "Venom Snake", "models/player/sanic/MGSVBigBossPM.mdl")
list.Set( "PlayerOptionsModel", "Venom Snake", "models/player/sanic/MGSVBigBossPM.mdl")
player_manager.AddValidHands( "Venom Snake", "models/weapons/c_arms_venom.mdl", 0, "11" )
